var nn={
'details':[

{'Permissions' : 'drwxr-xr-x', 'Replication':'-', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/adaaaa'},
{'Permissions' : 'drwxr-xr-x', 'Replication':'-', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/add'},
{'Permissions' : '-rw-r--r--', 'Replication':'3', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/post.log'},
{'Permissions' : 'drwxr-xr-x', 'Replication':'-', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/tmp'},
{'Permissions' : 'drwxr-xr-x', 'Replication':'-', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/tmp/hadoop-root'},
{'Permissions' : 'drwxr-xr-x', 'Replication':'-', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/tmp/hadoop-root/mapred'},
{'Permissions' : 'drwx------', 'Replication':'-', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/tmp/hadoop-root/mapred/system'},
{'Permissions' : '-rw-------', 'Replication':'3', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'4', 'UploadedOn':'2015-08-12','FName':'/tmp/hadoop-root/mapred/system/jobtracker.info'},
{'Permissions' : 'drwxr-xr-x', 'Replication':'-', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/user'},
{'Permissions' : 'drwxr-xr-x', 'Replication':'-', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/user/root'},
{'Permissions' : 'drwxr-xr-x', 'Replication':'-', 'UploadedBy':'root', 'UserGroup':'supergroup', 'Size':'0', 'UploadedOn':'2015-08-12','FName':'/user/root/adaa'},
]

}
 