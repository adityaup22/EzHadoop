var nn = {
"details":[
{"jobid":"1561231313","startedby":"xyz","complete":"cdsc","priority":"bht jyada"},
{"jobid":"1561231313","startedby":"zxv","complete":"ccci","priority":"bht jyada"},
{"jobid":"1561231313","startedby":"zc","complete":"dcsdc","priority":"bht jyada"},
{"jobid":"1561231313","startedby":"ds","complete":"scAS","priority":"bht jyada"},
{"jobid":"1561231313","startedby":"sdccsdc","complete":"dsd","priority":"bht jyada"},
{"jobid":"1561231313","startedby":"dscsdc","complete":"dscdc","priority":"bht jyada"},
{"jobid":"1561231313","startedby":"ssdcsdc","complete":"dcdcgi","priority":"bht jyada"},

]	
}