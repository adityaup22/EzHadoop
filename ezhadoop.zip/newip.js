var nn={
'details':[

{'IpAddress' : '192.168.0.68','Ram':'3820Mib','Disk':'42Gib'},
{'IpAddress' : '192.168.0.67','Ram':'3756Mib','Disk':'23Gib'},
{'IpAddress' : '192.168.0.69','Ram':'15697Mib','Disk':'42Gib'},
{'IpAddress' : '192.168.0.117','Ram':'3820Mib','Disk':'28Gib'},
{'IpAddress' : '192.168.0.21','Ram':'15697Mib','Disk':'42Gib'}, 
]

}
