$("#doughnutChart").drawDoughnutChart([
  { 
    title: "Nope, It's all just the web",
    value : 4822,  
    color: "#f3e32b" 
  },
  { 
    title: "Yep. They are different things with different concerns",
    value:  12339,   
    color: "#35a8ff" 
  }
]);